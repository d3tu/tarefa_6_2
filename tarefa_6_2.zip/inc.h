void joystick();
void buzzer();
void led();